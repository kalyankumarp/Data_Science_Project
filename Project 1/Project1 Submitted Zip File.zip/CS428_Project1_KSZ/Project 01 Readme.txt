Kalyan Kumar Paladugula kpalad4 679025059
Michael Ybarra mybarr3 659036727
Zoheb Mohammed zmoham2 654090066


All members contributed equally to all 10 tasks.

To run this project, please open the ipynb file inside Jupyter NOTEBOOK. This is important because the map for task 10 will not load if you don't use notebook. 